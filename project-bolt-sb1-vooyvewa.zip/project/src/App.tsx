import React, { useState, useEffect } from 'react';
import { 
  Menu, 
  X, 
  Calendar, 
  MapPin, 
  Users, 
  Mail, 
  Phone, 
  ExternalLink,
  Download,
  Clock,
  Award,
  Building,
  Car,
  CreditCard,
  FileText,
  Star,
  ChevronRight,
  Globe,
  Linkedin,
  Twitter
} from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  // Handle navigation clicks
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(sectionId);
      setIsMenuOpen(false);
    }
  };

  // Handle scroll to update active section
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'about', 'program', 'speakers', 'registration', 'papers', 'venue', 'sponsors', 'contact', 'news'];
      const current = sections.find(section => {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          return rect.top <= 100 && rect.bottom >= 100;
        }
        return false;
      });
      if (current) {
        setActiveSection(current);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navigation = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'program', label: 'Program' },
    { id: 'speakers', label: 'Speakers' },
    { id: 'registration', label: 'Register' },
    { id: 'papers', label: 'Call for Papers' },
    { id: 'venue', label: 'Venue' },
    { id: 'sponsors', label: 'Sponsors' },
    { id: 'contact', label: 'Contact' },
    { id: 'news', label: 'News' }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-md z-50 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-900 rounded-lg flex items-center justify-center">
                <Building className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">TechSymposium 2025</h1>
                <p className="text-sm text-gray-600">Innovation & Excellence</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center space-x-1">
              {navigation.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    activeSection === item.id
                      ? 'bg-blue-900 text-white'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-gray-700 hover:bg-gray-100"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden bg-white border-t border-gray-200">
            <div className="px-4 py-2">
              {navigation.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`block w-full text-left px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 ${
                    activeSection === item.id
                      ? 'bg-blue-900 text-white'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="pt-20 min-h-screen flex items-center bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-5xl lg:text-7xl font-bold text-white mb-6 leading-tight">
              National Technical
              <span className="block bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                Symposium 2025
              </span>
            </h1>
            <p className="text-xl lg:text-2xl text-blue-100 mb-8 max-w-3xl mx-auto leading-relaxed">
              Innovation, Excellence, and Future Technologies converge at the premier academic symposium
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <div className="flex items-center space-x-2 text-blue-100">
                <Calendar className="w-5 h-5" />
                <span className="text-lg font-medium">March 15-17, 2025</span>
              </div>
              <div className="hidden sm:block w-px h-6 bg-blue-400"></div>
              <div className="flex items-center space-x-2 text-blue-100">
                <MapPin className="w-5 h-5" />
                <span className="text-lg font-medium">University of Technology</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => scrollToSection('registration')}
                className="bg-yellow-500 hover:bg-yellow-600 text-black px-8 py-4 rounded-xl text-lg font-semibold transition-all duration-200 transform hover:scale-105 shadow-lg"
              >
                Register Now
              </button>
              <button
                onClick={() => scrollToSection('papers')}
                className="border-2 border-white text-white hover:bg-white hover:text-blue-900 px-8 py-4 rounded-xl text-lg font-semibold transition-all duration-200"
              >
                Submit Paper
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">About the Symposium</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              A premier platform for academics, researchers, and industry leaders to share groundbreaking research and innovations
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h3>
              <p className="text-gray-600 mb-6 text-lg leading-relaxed">
                To foster collaboration between academia and industry, promoting cutting-edge research in emerging technologies 
                and creating a platform for knowledge exchange that drives innovation forward.
              </p>
              
              <h4 className="text-xl font-semibold text-gray-900 mb-3">Key Objectives:</h4>
              <ul className="space-y-3">
                {[
                  'Showcase innovative research in computer science and engineering',
                  'Facilitate networking between students, researchers, and industry experts',
                  'Promote interdisciplinary collaboration and knowledge transfer',
                  'Recognize outstanding contributions to technological advancement'
                ].map((objective, index) => (
                  <li key={index} className="flex items-start space-x-3">
                    <ChevronRight className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">{objective}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-indigo-100 p-8 rounded-2xl">
              <h4 className="text-xl font-semibold text-gray-900 mb-6">Symposium Statistics</h4>
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">500+</div>
                  <div className="text-gray-700">Expected Participants</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">50+</div>
                  <div className="text-gray-700">Research Papers</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">20+</div>
                  <div className="text-gray-700">Industry Speakers</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">15+</div>
                  <div className="text-gray-700">Universities</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Program Section */}
      <section id="program" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">Program Schedule</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Three days of inspiring talks, research presentations, and networking opportunities
            </p>
          </div>

          <div className="space-y-8">
            {[
              {
                day: 'Day 1 - March 15, 2025',
                theme: 'Opening & Keynote Presentations',
                sessions: [
                  { time: '09:00-10:00', title: 'Registration & Welcome Coffee', type: 'break' },
                  { time: '10:00-11:00', title: 'Opening Ceremony', speaker: 'University Chancellor', type: 'ceremony' },
                  { time: '11:00-12:00', title: 'Keynote: Future of AI in Healthcare', speaker: 'Dr. Sarah Chen', type: 'keynote' },
                  { time: '12:00-13:00', title: 'Lunch Break', type: 'break' },
                  { time: '13:00-15:00', title: 'Research Paper Session A: Machine Learning', type: 'session' },
                  { time: '15:00-15:30', title: 'Coffee Break', type: 'break' },
                  { time: '15:30-17:00', title: 'Industry Panel: Tech Entrepreneurship', type: 'panel' }
                ]
              },
              {
                day: 'Day 2 - March 16, 2025',
                theme: 'Research Presentations & Workshops',
                sessions: [
                  { time: '09:00-10:00', title: 'Keynote: Quantum Computing Advances', speaker: 'Prof. Michael Rodriguez', type: 'keynote' },
                  { time: '10:00-10:30', title: 'Coffee Break', type: 'break' },
                  { time: '10:30-12:00', title: 'Research Paper Session B: IoT & Embedded Systems', type: 'session' },
                  { time: '12:00-13:00', title: 'Lunch Break', type: 'break' },
                  { time: '13:00-15:00', title: 'Workshop: Cloud Computing Best Practices', type: 'workshop' },
                  { time: '15:00-15:30', title: 'Coffee Break', type: 'break' },
                  { time: '15:30-17:00', title: 'Poster Session & Networking', type: 'networking' }
                ]
              },
              {
                day: 'Day 3 - March 17, 2025',
                theme: 'Innovation Showcase & Closing',
                sessions: [
                  { time: '09:00-10:00', title: 'Student Innovation Showcase', type: 'showcase' },
                  { time: '10:00-10:30', title: 'Coffee Break', type: 'break' },
                  { time: '10:30-12:00', title: 'Research Paper Session C: Cybersecurity', type: 'session' },
                  { time: '12:00-13:00', title: 'Lunch Break', type: 'break' },
                  { time: '13:00-14:00', title: 'Awards Ceremony', type: 'ceremony' },
                  { time: '14:00-15:00', title: 'Closing Remarks & Future Directions', type: 'closing' }
                ]
              }
            ].map((day, dayIndex) => (
              <div key={dayIndex} className="bg-white rounded-2xl shadow-lg overflow-hidden">
                <div className="bg-blue-900 px-8 py-6">
                  <h3 className="text-2xl font-bold text-white">{day.day}</h3>
                  <p className="text-blue-200">{day.theme}</p>
                </div>
                <div className="p-8">
                  <div className="space-y-4">
                    {day.sessions.map((session, sessionIndex) => (
                      <div key={sessionIndex} className={`flex items-center space-x-4 p-4 rounded-lg ${
                        session.type === 'keynote' ? 'bg-yellow-50 border-l-4 border-yellow-500' :
                        session.type === 'break' ? 'bg-gray-50' :
                        session.type === 'ceremony' ? 'bg-blue-50 border-l-4 border-blue-500' :
                        'bg-white border border-gray-200'
                      }`}>
                        <div className="flex items-center space-x-2 text-sm font-semibold text-gray-900 w-24">
                          <Clock className="w-4 h-4" />
                          <span>{session.time}</span>
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">{session.title}</h4>
                          {session.speaker && <p className="text-sm text-gray-600">{session.speaker}</p>}
                        </div>
                        {session.type === 'keynote' && <Star className="w-5 h-5 text-yellow-500" />}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Speakers Section */}
      <section id="speakers" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">Distinguished Speakers</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              World-renowned experts and thought leaders in technology and innovation
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                name: 'Dr. Sarah Chen',
                title: 'Chief AI Research Scientist',
                company: 'TechCorp Innovation Labs',
                bio: 'Leading expert in AI applications for healthcare with 15+ years of research experience.',
                expertise: ['Artificial Intelligence', 'Healthcare Technology', 'Machine Learning'],
                social: { linkedin: '#', twitter: '#' }
              },
              {
                name: 'Prof. Michael Rodriguez',
                title: 'Quantum Computing Research Director',
                company: 'Advanced Computing Institute',
                bio: 'Pioneer in quantum computing algorithms and quantum machine learning applications.',
                expertise: ['Quantum Computing', 'Quantum Algorithms', 'Cryptography'],
                social: { linkedin: '#', twitter: '#' }
              },
              {
                name: 'Dr. Priya Patel',
                title: 'VP of Engineering',
                company: 'CloudTech Solutions',
                bio: 'Visionary leader in cloud computing and distributed systems architecture.',
                expertise: ['Cloud Computing', 'Distributed Systems', 'DevOps'],
                social: { linkedin: '#', twitter: '#' }
              },
              {
                name: 'James Wilson',
                title: 'Cybersecurity Expert',
                company: 'SecureNet Technologies',
                bio: 'Renowned cybersecurity specialist with expertise in threat intelligence and security.',
                expertise: ['Cybersecurity', 'Threat Intelligence', 'Network Security'],
                social: { linkedin: '#', twitter: '#' }
              },
              {
                name: 'Dr. Lisa Zhang',
                title: 'IoT Research Lead',
                company: 'Smart Systems Lab',
                bio: 'Expert in Internet of Things and embedded systems for smart city applications.',
                expertise: ['Internet of Things', 'Embedded Systems', 'Smart Cities'],
                social: { linkedin: '#', twitter: '#' }
              },
              {
                name: 'Robert Kumar',
                title: 'Blockchain Technology Advisor',
                company: 'CryptoInnovate',
                bio: 'Blockchain technology expert and advisor for multiple fintech startups.',
                expertise: ['Blockchain', 'Cryptocurrency', 'FinTech'],
                social: { linkedin: '#', twitter: '#' }
              }
            ].map((speaker, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
                <div className="h-64 bg-gradient-to-br from-blue-500 to-purple-600 relative overflow-hidden">
                  <div className="absolute inset-0 bg-black/20"></div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mb-2">
                      <Users className="w-8 h-8 text-white" />
                    </div>
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-1">{speaker.name}</h3>
                  <p className="text-blue-600 font-semibold mb-1">{speaker.title}</p>
                  <p className="text-gray-600 text-sm mb-3">{speaker.company}</p>
                  <p className="text-gray-700 text-sm mb-4 leading-relaxed">{speaker.bio}</p>
                  
                  <div className="mb-4">
                    <div className="flex flex-wrap gap-2">
                      {speaker.expertise.map((skill, skillIndex) => (
                        <span key={skillIndex} className="bg-blue-100 text-blue-800 text-xs px-3 py-1 rounded-full">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex space-x-3">
                    <a href={speaker.social.linkedin} className="text-gray-400 hover:text-blue-600 transition-colors">
                      <Linkedin className="w-5 h-5" />
                    </a>
                    <a href={speaker.social.twitter} className="text-gray-400 hover:text-blue-400 transition-colors">
                      <Twitter className="w-5 h-5" />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Registration Section */}
      <section id="registration" className="py-20 bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">Registration</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Secure your spot at the premier technical symposium. Early bird discounts available!
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                type: 'Student',
                earlyBird: '$99',
                regular: '$149',
                features: [
                  'Access to all sessions',
                  'Conference materials',
                  'Lunch and coffee breaks',
                  'Student networking events',
                  'Certificate of participation'
                ],
                popular: false
              },
              {
                type: 'Academic',
                earlyBird: '$199',
                regular: '$299',
                features: [
                  'Access to all sessions',
                  'Conference materials',
                  'All meals included',
                  'Academic networking events',
                  'Proceedings access',
                  'Certificate of participation'
                ],
                popular: true
              },
              {
                type: 'Industry',
                earlyBird: '$399',
                regular: '$499',
                features: [
                  'Access to all sessions',
                  'Premium conference materials',
                  'All meals included',
                  'VIP networking events',
                  'Industry roundtable access',
                  'Digital proceedings',
                  'Certificate of participation'
                ],
                popular: false
              }
            ].map((plan, index) => (
              <div key={index} className={`bg-white rounded-2xl shadow-lg overflow-hidden ${plan.popular ? 'ring-4 ring-blue-500 transform scale-105' : ''}`}>
                {plan.popular && (
                  <div className="bg-blue-500 text-white text-center py-2 px-4">
                    <span className="text-sm font-semibold">Most Popular</span>
                  </div>
                )}
                
                <div className="p-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">{plan.type}</h3>
                  
                  <div className="mb-6">
                    <div className="flex items-baseline space-x-2">
                      <span className="text-3xl font-bold text-gray-900">{plan.earlyBird}</span>
                      <span className="text-lg text-gray-500 line-through">{plan.regular}</span>
                    </div>
                    <p className="text-sm text-green-600 font-semibold">Early Bird (Until Feb 15)</p>
                  </div>
                  
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start space-x-3">
                        <ChevronRight className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <button className={`w-full py-3 px-6 rounded-lg font-semibold transition-all duration-200 ${
                    plan.popular 
                      ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                      : 'bg-gray-900 hover:bg-black text-white'
                  }`}>
                    Register Now
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 bg-white rounded-2xl shadow-lg p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Registration Form</h3>
            
            <form className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Full Name</label>
                <input type="text" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Email Address</label>
                <input type="email" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Organization</label>
                <input type="text" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Registration Type</label>
                <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                  <option>Student</option>
                  <option>Academic</option>
                  <option>Industry</option>
                </select>
              </div>
              
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-700 mb-2">Special Requirements</label>
                <textarea rows={4} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"></textarea>
              </div>
              
              <div className="md:col-span-2">
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-200 flex items-center space-x-2">
                  <CreditCard className="w-5 h-5" />
                  <span>Proceed to Payment</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* Call for Papers Section */}
      <section id="papers" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">Call for Papers</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Share your groundbreaking research with the academic and industry community
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Submission Guidelines</h3>
              
              <div className="space-y-6">
                <div className="bg-blue-50 p-6 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Research Tracks</h4>
                  <ul className="text-gray-700 space-y-1">
                    <li>• Artificial Intelligence & Machine Learning</li>
                    <li>• Internet of Things & Embedded Systems</li>
                    <li>• Cybersecurity & Privacy</li>
                    <li>• Cloud Computing & Distributed Systems</li>
                    <li>• Quantum Computing</li>
                    <li>• Blockchain & Cryptocurrency</li>
                    <li>• Human-Computer Interaction</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Paper Format</h4>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex items-start space-x-2">
                      <ChevronRight className="w-4 h-4 mt-1 text-blue-600" />
                      <span>Maximum 8 pages (including references)</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <ChevronRight className="w-4 h-4 mt-1 text-blue-600" />
                      <span>IEEE conference format</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <ChevronRight className="w-4 h-4 mt-1 text-blue-600" />
                      <span>PDF format only</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <ChevronRight className="w-4 h-4 mt-1 text-blue-600" />
                      <span>Anonymous submission (double-blind review)</span>
                    </li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Review Process</h4>
                  <p className="text-gray-700 mb-3">
                    All submissions undergo rigorous peer review by at least three experts in the field.
                  </p>
                  <ul className="space-y-1 text-gray-700 text-sm">
                    <li>• Initial screening for scope and format</li>
                    <li>• Double-blind peer review process</li>
                    <li>• Notification with reviewer comments</li>
                    <li>• Camera-ready submission for accepted papers</li>
                  </ul>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Important Dates</h3>
              
              <div className="space-y-4 mb-8">
                {[
                  { date: 'January 15, 2025', event: 'Paper Submission Deadline', status: 'upcoming' },
                  { date: 'February 20, 2025', event: 'Review Notification', status: 'upcoming' },
                  { date: 'February 28, 2025', event: 'Camera-Ready Submission', status: 'upcoming' },
                  { date: 'March 15-17, 2025', event: 'Conference Dates', status: 'event' }
                ].map((item, index) => (
                  <div key={index} className={`p-4 rounded-lg border-l-4 ${
                    item.status === 'event' ? 'bg-blue-50 border-blue-500' : 'bg-gray-50 border-gray-300'
                  }`}>
                    <div className="font-semibold text-gray-900">{item.event}</div>
                    <div className="text-gray-600 text-sm">{item.date}</div>
                  </div>
                ))}
              </div>

              <div className="bg-gradient-to-br from-yellow-50 to-orange-50 p-6 rounded-lg mb-8">
                <h4 className="font-semibold text-gray-900 mb-2">Paper Templates</h4>
                <p className="text-gray-700 text-sm mb-4">
                  Download the official IEEE conference template for your submission.
                </p>
                <div className="flex space-x-3">
                  <button className="flex items-center space-x-2 bg-white hover:bg-gray-50 px-4 py-2 rounded-lg text-sm font-medium border border-gray-300 transition-colors">
                    <Download className="w-4 h-4" />
                    <span>LaTeX Template</span>
                  </button>
                  <button className="flex items-center space-x-2 bg-white hover:bg-gray-50 px-4 py-2 rounded-lg text-sm font-medium border border-gray-300 transition-colors">
                    <Download className="w-4 h-4" />
                    <span>Word Template</span>
                  </button>
                </div>
              </div>

              <div className="bg-white border-2 border-gray-200 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-4">Submit Your Paper</h4>
                <form className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Paper Title</label>
                    <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Research Track</label>
                    <select className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                      <option>Select a track...</option>
                      <option>AI & Machine Learning</option>
                      <option>IoT & Embedded Systems</option>
                      <option>Cybersecurity</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Upload Paper (PDF)</label>
                    <input type="file" accept=".pdf" className="w-full px-3 py-2 border border-gray-300 rounded-md" />
                  </div>
                  
                  <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md font-medium transition-colors">
                    Submit Paper
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Venue & Travel Section */}
      <section id="venue" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">Venue & Travel</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Join us at the state-of-the-art University of Technology campus in the heart of the city
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Conference Venue</h3>
              
              <div className="bg-white rounded-lg p-6 shadow-lg mb-8">
                <div className="flex items-center space-x-3 mb-4">
                  <Building className="w-6 h-6 text-blue-600" />
                  <h4 className="text-xl font-semibold text-gray-900">Main Auditorium</h4>
                </div>
                <p className="text-gray-700 mb-4">
                  University of Technology<br />
                  123 Innovation Drive<br />
                  Tech City, TC 12345
                </p>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium text-gray-900">Capacity:</span>
                    <p className="text-gray-600">800 attendees</p>
                  </div>
                  <div>
                    <span className="font-medium text-gray-900">Facilities:</span>
                    <p className="text-gray-600">WiFi, A/V, Catering</p>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg p-1 mb-8">
                <div className="bg-white rounded-lg p-6">
                  <h4 className="text-xl font-semibold text-gray-900 mb-4">Campus Map</h4>
                  <div className="bg-gray-100 h-48 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600">Interactive campus map</p>
                      <button className="text-blue-600 hover:text-blue-800 text-sm font-medium mt-2 flex items-center space-x-1 mx-auto">
                        <ExternalLink className="w-4 h-4" />
                        <span>View Full Map</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Travel Information</h3>
              
              <div className="space-y-6">
                <div className="bg-white rounded-lg p-6 shadow-lg">
                  <div className="flex items-center space-x-3 mb-4">
                    <Car className="w-6 h-6 text-blue-600" />
                    <h4 className="text-lg font-semibold text-gray-900">Transportation</h4>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <h5 className="font-medium text-gray-900 mb-2">From Airport</h5>
                      <ul className="text-gray-700 text-sm space-y-1">
                        <li>• Shuttle service available (20 minutes)</li>
                        <li>• Taxi/Uber: $25-35 (15 minutes)</li>
                        <li>• Public transit: Bus #42 (45 minutes)</li>
                      </ul>
                    </div>
                    
                    <div>
                      <h5 className="font-medium text-gray-900 mb-2">Parking</h5>
                      <ul className="text-gray-700 text-sm space-y-1">
                        <li>• On-campus parking: $10/day</li>
                        <li>• Street parking: Limited availability</li>
                        <li>• Validation available for attendees</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-lg p-6 shadow-lg">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Recommended Hotels</h4>
                  
                  <div className="space-y-4">
                    {[
                      { name: 'Grand Tech Hotel', distance: '0.5 miles', rate: '$150/night', amenities: 'WiFi, Pool, Gym' },
                      { name: 'University Inn', distance: '0.2 miles', rate: '$120/night', amenities: 'WiFi, Breakfast' },
                      { name: 'Business Suites', distance: '1.0 miles', rate: '$180/night', amenities: 'Full Kitchen, WiFi' }
                    ].map((hotel, index) => (
                      <div key={index} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h5 className="font-medium text-gray-900">{hotel.name}</h5>
                          <span className="text-sm font-semibold text-blue-600">{hotel.rate}</span>
                        </div>
                        <div className="text-sm text-gray-600">
                          <p className="mb-1">{hotel.distance} from venue</p>
                          <p>{hotel.amenities}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white rounded-lg p-6 shadow-lg">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Local Attractions</h4>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex items-start space-x-2">
                      <ChevronRight className="w-4 h-4 mt-1 text-blue-600" />
                      <span>Tech Museum of Innovation (2 miles)</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <ChevronRight className="w-4 h-4 mt-1 text-blue-600" />
                      <span>Downtown Cultural District (1.5 miles)</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <ChevronRight className="w-4 h-4 mt-1 text-blue-600" />
                      <span>Riverside Park & Walking Trails (1 mile)</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sponsors Section */}
      <section id="sponsors" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">Our Partners & Sponsors</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Supporting innovation and excellence in technology education and research
            </p>
          </div>

          <div className="space-y-12">
            {/* Platinum Sponsors */}
            <div>
              <h3 className="text-2xl font-bold text-center text-gray-900 mb-8">Platinum Sponsors</h3>
              <div className="grid md:grid-cols-2 gap-8">
                {[1, 2].map((sponsor) => (
                  <div key={sponsor} className="bg-gradient-to-br from-gray-50 to-gray-100 p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300">
                    <div className="h-24 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center mb-4">
                      <Building className="w-12 h-12 text-white" />
                    </div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">TechCorp Solutions</h4>
                    <p className="text-gray-600 text-sm">Leading provider of enterprise technology solutions and cloud computing services.</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Gold Sponsors */}
            <div>
              <h3 className="text-2xl font-bold text-center text-gray-900 mb-8">Gold Sponsors</h3>
              <div className="grid md:grid-cols-3 gap-6">
                {[1, 2, 3].map((sponsor) => (
                  <div key={sponsor} className="bg-white border border-gray-200 p-6 rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="h-16 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-lg flex items-center justify-center mb-4">
                      <Globe className="w-8 h-8 text-white" />
                    </div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">Innovation Labs</h4>
                    <p className="text-gray-600 text-sm">Research and development in AI and machine learning technologies.</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Silver Sponsors */}
            <div>
              <h3 className="text-2xl font-bold text-center text-gray-900 mb-8">Silver Sponsors</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[1, 2, 3, 4].map((sponsor) => (
                  <div key={sponsor} className="bg-white border border-gray-200 p-4 rounded-lg shadow-sm hover:shadow-md transition-all duration-300">
                    <div className="h-12 bg-gray-400 rounded-md flex items-center justify-center mb-2">
                      <Building className="w-6 h-6 text-white" />
                    </div>
                    <h5 className="text-sm font-semibold text-gray-900">StartupTech</h5>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sponsorship Packages */}
          <div className="mt-16 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-2xl p-8">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Become a Sponsor</h3>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Partner with us to showcase your brand to 500+ technology professionals, researchers, and students
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {[
                {
                  package: 'Platinum',
                  price: '$10,000',
                  benefits: ['Logo on all materials', 'Keynote speaking slot', 'Premium booth space', 'Full attendee list']
                },
                {
                  package: 'Gold',
                  price: '$5,000',
                  benefits: ['Logo on website', 'Exhibition booth', 'Welcome message', 'Networking access']
                },
                {
                  package: 'Silver',
                  price: '$2,500',
                  benefits: ['Logo placement', 'Brochure inclusion', 'Social media mention', 'Certificate']
                }
              ].map((pkg, index) => (
                <div key={index} className="bg-white rounded-xl p-6 shadow-md">
                  <h4 className="text-xl font-bold text-gray-900 mb-2">{pkg.package}</h4>
                  <div className="text-2xl font-bold text-blue-600 mb-4">{pkg.price}</div>
                  <ul className="space-y-2">
                    {pkg.benefits.map((benefit, benefitIndex) => (
                      <li key={benefitIndex} className="flex items-start space-x-2">
                        <Award className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                        <span className="text-gray-700 text-sm">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            <div className="text-center mt-8">
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors">
                Download Sponsorship Brochure
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">Contact Us</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Have questions? Get in touch with our organizing committee
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-8">Organizing Committee</h3>
              
              <div className="space-y-6">
                {[
                  {
                    role: 'General Chair',
                    name: 'Dr. Emily Johnson',
                    title: 'Professor, Computer Science',
                    email: 'chair@techsymposium.edu',
                    phone: '+1 (555) 123-4567'
                  },
                  {
                    role: 'Program Chair',
                    name: 'Prof. David Chen',
                    title: 'Associate Professor, Engineering',
                    email: 'program@techsymposium.edu',
                    phone: '+1 (555) 123-4568'
                  },
                  {
                    role: 'Registration Chair',
                    name: 'Dr. Sarah Wilson',
                    title: 'Assistant Professor, IT',
                    email: 'registration@techsymposium.edu',
                    phone: '+1 (555) 123-4569'
                  }
                ].map((member, index) => (
                  <div key={index} className="bg-white rounded-xl p-6 shadow-lg">
                    <h4 className="text-lg font-bold text-blue-600 mb-2">{member.role}</h4>
                    <h5 className="text-xl font-semibold text-gray-900 mb-1">{member.name}</h5>
                    <p className="text-gray-600 mb-4">{member.title}</p>
                    
                    <div className="space-y-2">
                      <div className="flex items-center space-x-3">
                        <Mail className="w-4 h-4 text-gray-400" />
                        <a href={`mailto:${member.email}`} className="text-blue-600 hover:text-blue-800 transition-colors">
                          {member.email}
                        </a>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Phone className="w-4 h-4 text-gray-400" />
                        <span className="text-gray-700">{member.phone}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-8">Send Us a Message</h3>
              
              <form className="bg-white rounded-xl p-8 shadow-lg space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">First Name</label>
                    <input type="text" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Last Name</label>
                    <input type="text" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Email Address</label>
                  <input type="email" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Subject</label>
                  <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <option>General Inquiry</option>
                    <option>Registration Question</option>
                    <option>Paper Submission</option>
                    <option>Sponsorship</option>
                    <option>Technical Support</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Message</label>
                  <textarea rows={6} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"></textarea>
                </div>
                
                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-6 rounded-lg font-semibold transition-colors">
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* News Section */}
      <section id="news" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">Latest News & Updates</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Stay informed with the latest symposium announcements and important updates
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                date: 'January 10, 2025',
                title: 'Early Bird Registration Extended',
                excerpt: 'Due to popular demand, we have extended the early bird registration deadline until February 15th. Take advantage of discounted rates!',
                category: 'Registration',
                featured: true
              },
              {
                date: 'January 8, 2025',
                title: 'Keynote Speaker Announced',
                excerpt: 'We are excited to announce Dr. Sarah Chen as our opening keynote speaker, presenting on AI applications in healthcare.',
                category: 'Speakers',
                featured: false
              },
              {
                date: 'January 5, 2025',
                title: 'Call for Papers Reminder',
                excerpt: 'Paper submission deadline is approaching fast! Submit your research by January 15th to be considered for presentation.',
                category: 'Papers',
                featured: false
              },
              {
                date: 'December 20, 2024',
                title: 'Venue Details Released',
                excerpt: 'Complete venue information including campus maps, parking details, and accessibility information is now available.',
                category: 'Venue',
                featured: false
              },
              {
                date: 'December 15, 2024',
                title: 'Sponsorship Opportunities',
                excerpt: 'New sponsorship packages are available. Partner with us to reach 500+ technology professionals and researchers.',
                category: 'Sponsors',
                featured: false
              },
              {
                date: 'December 10, 2024',
                title: 'Registration Now Open',
                excerpt: 'Registration is officially open! Secure your spot at the premier technical symposium with early bird pricing.',
                category: 'Registration',
                featured: false
              }
            ].map((news, index) => (
              <div key={index} className={`bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 ${
                news.featured ? 'lg:col-span-2' : ''
              }`}>
                <div className={`${
                  news.featured 
                    ? 'h-48 bg-gradient-to-br from-blue-600 to-purple-600' 
                    : 'h-32 bg-gradient-to-br from-gray-500 to-gray-600'
                } relative overflow-hidden`}>
                  <div className="absolute inset-0 bg-black/20"></div>
                  <div className="absolute top-4 left-4">
                    <span className="bg-white/20 text-white px-3 py-1 rounded-full text-sm font-medium">
                      {news.category}
                    </span>
                  </div>
                  {news.featured && (
                    <div className="absolute top-4 right-4">
                      <Star className="w-6 h-6 text-yellow-400 fill-current" />
                    </div>
                  )}
                </div>
                
                <div className="p-6">
                  <div className="text-sm text-gray-500 mb-2">{news.date}</div>
                  <h3 className={`font-bold text-gray-900 mb-3 ${
                    news.featured ? 'text-xl' : 'text-lg'
                  }`}>
                    {news.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed mb-4">{news.excerpt}</p>
                  <button className="text-blue-600 hover:text-blue-800 font-medium text-sm flex items-center space-x-1 transition-colors">
                    <span>Read more</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <button className="bg-gray-900 hover:bg-black text-white px-8 py-3 rounded-lg font-semibold transition-colors">
              View All News
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Building className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-xl font-bold">TechSymposium 2025</h3>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed">
                The premier national technical symposium bringing together the best minds in technology and innovation.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-300">
                {['About', 'Program', 'Speakers', 'Registration', 'Papers'].map((link) => (
                  <li key={link}>
                    <button 
                      onClick={() => scrollToSection(link.toLowerCase())}
                      className="hover:text-white transition-colors"
                    >
                      {link}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
              <div className="space-y-2 text-gray-300 text-sm">
                <div className="flex items-center space-x-2">
                  <Mail className="w-4 h-4" />
                  <span>info@techsymposium.edu</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone className="w-4 h-4" />
                  <span>+1 (555) 123-4567</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="w-4 h-4" />
                  <span>University of Technology</span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Important Dates</h4>
              <ul className="space-y-2 text-gray-300 text-sm">
                <li>Early Bird: Feb 15</li>
                <li>Paper Deadline: Jan 15</li>
                <li>Conference: Mar 15-17</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; 2025 TechSymposium. All rights reserved. | Organized by University of Technology</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;